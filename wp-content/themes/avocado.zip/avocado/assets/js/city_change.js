jQuery(document).ready(function() {
    jQuery('.city_change').on('click', function() {
        var buttonValue = jQuery(this).data('value');
        jQuery('.current_city').text(buttonValue);
        jQuery.ajax({
        type: 'POST',
        url: window.location.href,
        data: {myData: buttonValue}
        });
    });
});
