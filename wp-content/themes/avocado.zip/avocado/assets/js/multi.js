new SlimSelect({
    select: "#location",
    settings: {
        placeholderText: "Любое местоположение",
        searchPlaceholder: "Поиск..."
    }
})
new SlimSelect({
    select: "#type",
    settings: {
        placeholderText: "Любой тип",
        searchPlaceholder: "Поиск..."
    }
})
new SlimSelect({
    select: "#id",
    settings: {
        placeholderText: "Любой ID",
        searchPlaceholder: "Поиск..."
    }
})
new SlimSelect({
    select: "#city",
    settings: {
        searchPlaceholder: "Поиск..."
    }
})
new SlimSelect({
    select: "#rooms-number",
    settings: {
        searchPlaceholder: "Поиск..."
    }
})